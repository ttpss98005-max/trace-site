# 軌跡 TRACE

專案進度追蹤網站。登入與資料同步使用 Firebase（Google 登入 + Firestore）。

## 設定步驟

1. 到 https://console.firebase.google.com 開啟現有專案，或建立新專案。
2. Authentication > Sign-in method：啟用 Google。
3. Firestore Database：建立資料庫（已有就跳過）。
4. Firestore > 規則：加入 `firestore.rules` 裡 `match /users/{uid}/trace/{doc}` 那一段。
   如果這個 Firebase 專案已經給其他網站使用，**只加這一段，不要覆蓋原有規則**。
5. `firebase-config.js` 已填入 trace-site-26529 專案的設定。
6. 把解壓後的所有檔案放上靜態網站空間，例如 GitHub Pages 或 Firebase Hosting。
7. Authentication > Settings > Authorized domains：加入你的網域（例如 `你的帳號.github.io`）。

## 安裝到桌面

用 Chrome 或 Edge 開啟網站，按「全部專案」的「安裝到桌面」，或網址列右側的安裝圖示。
Android 也會出現安裝選項；iPhone 請用 Safari 的分享按鈕選「加入主畫面」。

## 資料位置

每個專案存在 Firestore 的 `projects/{id}`，只有成員能讀寫，最多 20 人。邀請碼存在 `invites/{code}`。舊版 `users/{uid}/trace/board` 會在第一次登入時自動複製過去，原資料保留不刪。

## 備份

「全部專案」的「備份與還原」可以匯出、匯入 JSON，也能還原自動保留的版本。
自動備份存在 `users/{uid}/trace/backup-0` 到 `backup-9`，只有本人能讀寫。
還原與匯入都會新增專案複本，不會覆蓋現有內容。

## 資料保護

每次寫入都帶資料版本（`schema`）。還開著舊版網頁的裝置遇到新版資料時，會停止寫入並提示重新整理，不會蓋掉新資料。
新版本第一次讀到既有資料時會先自動備份一份。舊版 `users/{uid}/trace/board` 保留不刪。

## 注意

- 必須透過 http(s) 網址開啟；直接雙擊 index.html 無法用 Google 登入。
- 第一次登入需要網路，之後離線修改會在連線後同步。
- 兩個帳號同時修改時會自動合併；只有改到同一節點的同一欄位時，以後存檔的為準。
- 更新網站時若 firestore.rules 有變動，要到 Firestore > 規則重新發布。
