# 軌跡 TRACE

專案進度追蹤網站。登入與資料同步使用 Firebase（Google 登入 + Firestore）。

## 設定步驟

1. 到 https://console.firebase.google.com 開啟現有專案，或建立新專案。
2. Authentication > Sign-in method：啟用 Google。
3. Firestore Database：建立資料庫（已有就跳過）。
4. Firestore > 規則：加入 `firestore.rules` 裡 `match /users/{uid}/trace/{doc}` 那一段。
   如果這個 Firebase 專案已經給其他網站使用，**只加這一段，不要覆蓋原有規則**。
5. `firebase-config.js` 已填入 trace-site-26529 專案的設定。
6. 把解壓後的所有檔案放上靜態網站空間，例如 GitHub Pages 或 Firebase Hosting。
7. Authentication > Settings > Authorized domains：加入你的網域（例如 `你的帳號.github.io`）。

## 資料位置

每位使用者的資料存在 Firestore 的 `users/{uid}/trace/board`，只有本人能讀寫。

## 注意

- 必須透過 http(s) 網址開啟；直接雙擊 index.html 無法用 Google 登入。
- 第一次登入需要網路，之後離線修改會在連線後同步。
- 兩台裝置同時修改時，以最後存檔的為準。
