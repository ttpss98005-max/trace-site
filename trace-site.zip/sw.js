const CACHE="trace-f480de5600";
const SHELL=["./","manifest.webmanifest","firebase-config.js","backend.js","icons/icon-192.png","icons/icon-512.png"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(n=>n.startsWith("trace-")&&n!==CACHE).map(n=>caches.delete(n)))).then(()=>self.clients.claim()))});
self.addEventListener("fetch",e=>{
  const r=e.request;if(r.method!=="GET")return;
  const u=new URL(r.url);
  if(u.origin===location.origin){
    /* newest version when online, cached copy when offline */
    e.respondWith(fetch(r).then(x=>{if(x.ok){const y=x.clone();caches.open(CACHE).then(c=>c.put(r,y))}return x}).catch(()=>caches.match(r).then(x=>x||(r.mode==="navigate"?caches.match("./"):Response.error()))));
  }else if(u.hostname==="www.gstatic.com"&&u.pathname.startsWith("/firebasejs/")){
    /* versioned SDK files never change */
    e.respondWith(caches.match(r).then(x=>x||fetch(r).then(y=>{const z=y.clone();caches.open(CACHE).then(c=>c.put(r,z));return y})));
  }
});
