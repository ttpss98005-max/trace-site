(function () {
  var cfg = window.TRACE_FIREBASE_CONFIG;
  if (!cfg || !cfg.apiKey) { window.TRACE_BACKEND = { configured: false }; return; }
  firebase.initializeApp(cfg);
  var auth = firebase.auth(), db = firebase.firestore();
  db.enablePersistence({ synchronizeTabs: true }).catch(function () {});
  window.TRACE_BACKEND = {
    configured: true,
    onAuth: function (cb) { return auth.onAuthStateChanged(cb); },
    signIn: function () {
      var provider = new firebase.auth.GoogleAuthProvider();
      provider.setCustomParameters({ prompt: "select_account" });
      return auth.signInWithPopup(provider).catch(function (e) {
        if (e && e.code === "auth/popup-blocked") return auth.signInWithRedirect(provider);
        throw e;
      });
    },
    signOut: function () { return auth.signOut(); },
    doc: function (uid) {
      var ref = db.collection("users").doc(uid).collection("trace").doc("board");
      return {
        set: function (d) { return ref.set(d); },
        onSnapshot: function (next, err) { return ref.onSnapshot({ includeMetadataChanges: true }, next, err); }
      };
    }
  };
})();
