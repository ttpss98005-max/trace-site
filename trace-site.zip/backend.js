(function () {
  var cfg = window.TRACE_FIREBASE_CONFIG;
  if (!cfg || !cfg.apiKey) { window.TRACE_BACKEND = { configured: false }; return; }
  firebase.initializeApp(cfg);
  var auth = firebase.auth(), db = firebase.firestore();
  db.enablePersistence({ synchronizeTabs: true }).catch(function () {});
  var ALPHA = "23456789ABCDEFGHJKMNPQRSTUVWXYZ";
  function newCode() {
    var a = new Uint32Array(8), s = "", i;
    crypto.getRandomValues(a);
    for (i = 0; i < 8; i++) s += ALPHA[a[i] % ALPHA.length];
    return s;
  }
  var projects = db.collection("projects"), invites = db.collection("invites");
  function userDoc(uid, name) { return db.collection("users").doc(uid).collection("trace").doc(name); }
  window.TRACE_BACKEND = {
    configured: true,
    onAuth: function (cb) { return auth.onAuthStateChanged(cb); },
    signIn: function () {
      var provider = new firebase.auth.GoogleAuthProvider();
      provider.setCustomParameters({ prompt: "select_account" });
      return auth.signInWithPopup(provider).catch(function (e) {
        if (e && e.code === "auth/popup-blocked") return auth.signInWithRedirect(provider);
        throw e;
      });
    },
    signOut: function () { return auth.signOut(); },
    getPrefs: function (uid) { return userDoc(uid, "prefs").get().then(function (d) { return d.exists ? d.data() : null; }); },
    setPrefs: function (uid, data) { return userDoc(uid, "prefs").set(data, { merge: true }); },
  getTemplates: function (uid) { return userDoc(uid, "templates").get().then(function (d) { return d.exists ? d.data() : null; }); },
  setTemplates: function (uid, rec) { return userDoc(uid, "templates").set(rec); },
    getOldBoard: function (uid) { return userDoc(uid, "board").get().then(function (d) { return d.exists ? d.data() : null; }); },
    setBackup: function (uid, slot, rec) { return userDoc(uid, "backup-" + slot).set(rec); },
    listBackups: function (uid, max) {
      var jobs = [], i;
      for (i = 0; i < max; i++) jobs.push(userDoc(uid, "backup-" + i).get());
      return Promise.all(jobs).then(function (docs) {
        return docs.map(function (d, i) { if (!d.exists) return null; var r = d.data(); r.slot = i; return r; }).filter(Boolean)
          .sort(function (a, b) { return a.at < b.at ? 1 : -1; });
      });
    },
    createProject: function (pid, data) { return projects.doc(pid).set(data); },
    deleteProject: function (pid) { return projects.doc(pid).delete(); },
    watchProjects: function (uid, next, err) {
      return projects.where("members", "array-contains", uid).onSnapshot({ includeMetadataChanges: true }, function (qs) {
        next(qs.docs.map(function (d) { return { id: d.id, data: d.data() }; }), qs.metadata.fromCache);
      }, err);
    },
    /* read-merge-write in a transaction so two accounts cannot overwrite each other */
    mergeSave: function (pid, build) {
      var ref = projects.doc(pid);
      return db.runTransaction(function (tx) {
        return tx.get(ref).then(function (snap) {
          var out = build(snap.exists ? snap.data() : null);
          if (out === null) return null;
          if (out.abort) return { abort: true };
          tx.set(ref, out.data, { merge: !out.create });
          return { json: out.data.json };
        });
      });
    },
    deleteInvite: function (code) { return invites.doc(code).delete(); },
    createInvite: function (pid, uid) {
      var code = newCode();
      return invites.doc(code).set({
        projectId: pid, createdBy: uid, usedBy: null,
        expiresAt: firebase.firestore.Timestamp.fromMillis(Date.now() + 7 * 864e5)
      }).then(function () { return code; });
    },
    join: function (code, uid, info) {
      var ref = invites.doc(code);
      return ref.get().then(function (d) {
        if (!d.exists) return { error: "missing" };
        var inv = d.data();
        if (inv.createdBy === uid) return { error: "self" };
        if (inv.usedBy) return { error: "used" };
        if (inv.expiresAt.toMillis() < Date.now()) return { error: "expired" };
        var batch = db.batch(), patch = {
          members: firebase.firestore.FieldValue.arrayUnion(uid), joinedWith: code
        };
        patch["memberInfo." + uid] = info;
        batch.update(ref, { usedBy: uid });
        batch.update(projects.doc(inv.projectId), patch);
        return batch.commit().then(function () { return { projectId: inv.projectId }; });
      });
    },
    removeMember: function (pid, uid) {
      var patch = { members: firebase.firestore.FieldValue.arrayRemove(uid) };
      patch["memberInfo." + uid] = firebase.firestore.FieldValue.delete();
      return projects.doc(pid).update(patch);
    }
  };
})();
