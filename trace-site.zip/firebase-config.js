// 把 Firebase 主控台「專案設定 > 你的應用程式 > 設定」裡的內容貼到下面。
// 這些值本來就會公開在網頁裡，資料安全由 firestore.rules 保護。
window.TRACE_FIREBASE_CONFIG = {
  apiKey: "AIzaSyCN5cO1J0ddSZ5z51SZNOHhoHUawj45BRc",
  authDomain: "trace-site-26529.firebaseapp.com",
  projectId: "trace-site-26529",
  appId: "1:1046471367148:web:4daac9965b48c2111248c9"
};
